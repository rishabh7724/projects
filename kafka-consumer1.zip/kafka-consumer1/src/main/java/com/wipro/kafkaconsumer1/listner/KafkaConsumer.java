/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wipro.kafkaconsumer1.listner;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.wipro.kafkaconsumer1.model.User;

/**
 *
 * @author Rishabh
 */
@Service
public class KafkaConsumer {
 
    @KafkaListener(groupId = "group_id",topics = "NewTopic0")
    public void consume(String message){
        System.out.println("Consumed Message : "+message);
    }
    
//    @KafkaListener(groupId = "group_json",topics = "NewTopic0")
//    public void consumeJson(User user){
//        System.out.println("Consumed JSON Message : " + user.toString());
//    }
}
